import threading

thread_locals = threading.local()
