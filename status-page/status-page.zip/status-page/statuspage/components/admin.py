from django.contrib import admin

# from .models import Component, ComponentGroup

# admin.site.register(Component)
# admin.site.register(ComponentGroup)
