from extras.plugins import PluginMenuItem

menu_items = (
    PluginMenuItem(
        link='plugins:sp_uptimerobot:uptimerobotmonitor_list',
        link_text='Monitors',
    ),
)
