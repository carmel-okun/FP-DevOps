import Alpine from 'alpinejs';

export function initWindow(): void {
  // @ts-ignore
  window.Alpine = Alpine
}
